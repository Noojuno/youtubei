export const INNERTUBE_CLIENT_VERSION = "2.20201209.01.00";
export const INNERTUBE_API_KEY = "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8";
export const BASE_URL = "www.youtube.com";
export const I_END_POINT = "/youtubei/v1";
export const LIVE_CHAT_END_POINT = `${I_END_POINT}/live_chat/get_live_chat`;
export const WATCH_END_POINT = "/watch";
export const COMMENT_END_POINT = "/comment_service_ajax";
