import { Base, ChannelCompact, Video, BaseAttributes, Chat } from ".";
import { YoutubeRawData } from "../common";
import { ChatAttributes } from "./Chat";

interface SuperChatColors {
  headerBackground: number;
  headerText: number;
  bodyBackground: number;
  bodyText: number;
}

export interface SuperChatAttributes extends ChatAttributes {
  purchaseAmount: string;
	colors: SuperChatColors;
}

/** Represents a chat in a live stream */
export default class SuperChat extends Chat implements SuperChatAttributes {
	/** The video this chat belongs to */
	video!: Video;
	/** The chat's author */
	author!: ChannelCompact;
	/** The message of this chat */
	message!: string;
	/** Timestamp in usec / microsecond */
	timestamp!: number;
  /** Purchase amount in string form including currency (e.g NZ$2.00) */
  purchaseAmount!: string;
  /** Colors of the super chat box */
  colors!: SuperChatColors;

	/** @hidden */
	constructor(chat: Partial<SuperChatAttributes> = {}) {
		super();
		Object.assign(this, chat);
	}

	/**
	 * Load this instance with raw data from Youtube
	 *
	 * @hidden
	 */
	load(data: YoutubeRawData): Chat {
		const {
			id,
			message,
			authorName,
			authorPhoto,
			timestampUsec,
			authorExternalChannelId,
      purchaseAmountText,
      headerBackgroundColor,
      headerTextColor,
      bodyBackgroundColor,
      bodyTextColor
		} = data;

		// Basic information
		this.id = id;
		this.message = message.runs.map((r: YoutubeRawData) => r.text).join("");
		this.author = new ChannelCompact({
			id: authorExternalChannelId,
			name: authorName.simpleText,
			thumbnails: authorPhoto.thumbnails,
			client: this.client,
		});
		this.timestamp = +timestampUsec;
    this.purchaseAmount = purchaseAmountText?.simpleText;
		return this;
	}
}
